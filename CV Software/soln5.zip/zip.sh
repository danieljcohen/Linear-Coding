#!/bin/bash

zip -FSr soln5.zip . -x ".*" -x "__MACOSX" -x "*Icon*" -x "assgn5.pdf" -x "./scripts/*"

