import numpy as np
import scipy.io
from nn import *
from tqdm import tqdm

train_data = scipy.io.loadmat('../data/nist36_train.mat')
valid_data = scipy.io.loadmat('../data/nist36_valid.mat')

train_x, train_y = train_data['train_data'], train_data['train_labels']
valid_x, valid_y = valid_data['valid_data'], valid_data['valid_labels']

max_iters = 200
# pick a batch size, learning rate
batch_size = 15
learning_rate = 1e-3
hidden_size = 64

batches = get_random_batches(train_x,train_y,batch_size)
batch_num = len(batches)

params = {}

# initialize layers here
initialize_weights(train_x.shape[1],hidden_size,params,'layer1')
initialize_weights(hidden_size,train_y.shape[1],params,'output')
import copy
w_init = copy.deepcopy(params["Wlayer1"])

train_acc_list = []
valid_acc_list = []
train_loss_list = []
# with default settings, you should get accuracy > 80%
progress_bar = tqdm(range(1,max_iters+1))
for itr in progress_bar:
    total_loss = 0
    total_acc = 0
    for xb,yb in batches:
        post_act1 = forward(xb,params,name="layer1")
        post_act2 = forward(post_act1,params,name="output",activation=softmax)
        # loss
        loss,acc = compute_loss_and_acc(yb,post_act2)
        delta1 = post_act2 - yb
        # be sure to add loss and accuracy to epoch totals 
        total_acc += acc
        total_loss += loss
        # backward
        delta2 = backwards(delta1,params,'output',linear_deriv)
        backwards(delta2,params,'layer1',sigmoid_deriv)
        # apply gradient
        for k,v in sorted(list(params.items())):
            if 'grad' in k:
                name = k.split('_')[1]
                params[name] -= learning_rate*v
    total_acc = total_acc/batch_num
    total_loss/=batch_num
    train_acc_list.append(total_acc)
    train_loss_list.append(total_loss)
    # run on validation set and report accuracy! should be above 75%
    valid_acc = 0
    post_act1 = forward(valid_x,params,name="layer1")
    post_act2 = forward(post_act1,params,name="output",activation=softmax)
    # loss
    _,valid_acc = compute_loss_and_acc(valid_y,post_act2)
    valid_acc_list.append(valid_acc)
    # be sure to add loss and accuracy to epoch totals
    progress_bar.set_description("itr: {:02d}, loss: {:.2f}, acc : {:.2f}, val acc: {:.4f}".format(itr,total_loss,total_acc,valid_acc))


#plot data:
import matplotlib
import matplotlib.pyplot as plt
if True:
    fig, axes = plt.subplots(nrows=1, ncols=2, figsize=(10, 5))
    
    # Plot accuracy
    axes[0].plot(range(1, len(train_acc_list) + 1), train_acc_list, label='Training Accuracy', marker='o')
    axes[0].plot(range(1, len(valid_acc_list) + 1), valid_acc_list, label='Validation Accuracy', marker='o')
    axes[0].set_xlabel('Epoch')
    axes[0].set_ylabel('Accuracy')
    axes[0].set_title('Accuracy over Epochs')
    axes[0].legend()
    axes[0].grid(True)

    # Plot loss
    axes[1].plot(range(1, len(train_loss_list) + 1), train_loss_list, label='Training Loss', marker='o')
    axes[1].set_xlabel('Epoch')
    axes[1].set_ylabel('Cross-Entropy Loss')
    axes[1].set_title('Cross-Entropy Loss over Epochs')
    axes[1].legend()
    axes[1].grid(True)

    # Adjust layout
    plt.tight_layout()
    
    # Show the plot
    plt.show()


if True: # view the data
    for crop in xb:
        import matplotlib.pyplot as plt
        print(crop)
        plt.imshow(crop.reshape(32,32).T)
        plt.show()
import pickle
saved_params = {k:v for k,v in params.items() if '_' not in k}
with open('q3_weights.pickle', 'wb') as handle:
    pickle.dump(saved_params, handle, protocol=pickle.HIGHEST_PROTOCOL)

# Q4.3
#matplotlib.use('agg')
from mpl_toolkits.axes_grid1 import ImageGrid

im = []
im.append(params["Wlayer1"])

fig = plt.figure(1, (5, 10))
grid = ImageGrid(fig, 111,  # similar to subplot(111)
                 nrows_ncols=(1, 2),  # creates 2x2 grid of axes
                 axes_pad=0.2,  # pad between axes in inch.
                 )
grid[1].imshow(im[0])  
grid[0].imshow(w_init)
plt.show()


# Q4.4
post_act1 = forward(valid_x,params,name="layer1")
probs = forward(post_act1,params,name="output",activation=softmax)
max_ind = np.argmax(probs,axis=1)
confusion_matrix = np.zeros((train_y.shape[1],train_y.shape[1]))
for i in range(len(max_ind)):
    confusion_matrix[max_ind[i],np.argmax(valid_y[i])] +=1


import string
plt.imshow(confusion_matrix,interpolation='nearest')
plt.grid(True)
plt.xticks(np.arange(36),string.ascii_uppercase[:26] + ''.join([str(_) for _ in range(10)]))
plt.yticks(np.arange(36),string.ascii_uppercase[:26] + ''.join([str(_) for _ in range(10)]))
plt.show()
